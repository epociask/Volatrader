import unittest
class TestBackTesterSession(unittest.TestCase):


    def testReset(self):
        pass